/***************************************************** 
 * Note: this file is provided for the convenience of
 *       students. Students can choose to edit, delete
 *       or even leave the file as-is. This file will
 *       NOT be replaced during grading.
 ****************************************************/
#ifndef UTILS_H_

#define UTILS_H_

int partition(char *key, int num_partitions);

#endif 
